package com.hulian.evenhandle.pagerdetail;

import com.hulian.evenhandle.R;
import com.hulian.evenhandle.base.BaseMenuDetailPager;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.app.Activity;

import android.view.View;
import android.widget.Button;

public class Test extends BaseMenuDetailPager {
	@ViewInject(R.id.button1)
	private Button mViewPager;

	public Test(Activity activity) {
		super(activity);	}

	@Override
	public View initView() {
		View view = View.inflate(mActivity, R.layout.servicecontent_layout, null);
		ViewUtils.inject(this, view);
		return view;		
	}

}
