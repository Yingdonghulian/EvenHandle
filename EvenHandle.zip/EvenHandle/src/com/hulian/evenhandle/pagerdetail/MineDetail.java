package com.hulian.evenhandle.pagerdetail;

import com.hulian.evenhandle.R;
import com.hulian.evenhandle.base.BaseMenuDetailPager;
import com.lidroid.xutils.ViewUtils;

import android.app.Activity;
import android.view.View;

public class MineDetail extends BaseMenuDetailPager {

	public MineDetail(Activity activity) {
		super(activity);
	}

	@Override
	public View initView() {
		View view = View.inflate(mActivity, R.layout.mine_detail, null);
        ViewUtils.inject(view);
		return view;
 
	}

}
