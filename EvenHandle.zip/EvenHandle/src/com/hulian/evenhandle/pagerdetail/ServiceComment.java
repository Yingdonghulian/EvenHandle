package com.hulian.evenhandle.pagerdetail;

import com.hulian.evenhandle.R;

import android.app.Activity;
import android.app.DownloadManager.Request;
import android.os.Bundle;
import android.view.Window;

public class ServiceComment extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
	    setContentView(R.layout.servicemangent);	
	}

}
